/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guayabita;

/**
 *
 * @author Estudiantes
 */
public class Guayabita {

    public static void main(String[] args) {

        Guayabita(Random(), 0);
    }
    
    public static int Random(){
        
        return (int) (Math.random() * 6) + 1;
    }
    
    
    public static void Guayabita(int x, int v){  
        
        
        if(x!=1 && x!=6){
            System.out.println("Tu dado es " + x );
            if(v==0){
                Guayabita(Random(),x);
            }else{ 
                if(x>v){
                     System.out.println("Ganas 100 y tu dado 1 es " + v + " tu dado 2 es " + x);
                }else{
                  System.out.println("Pierdes 100 y tu dado 1 es " + v + " tu dado 2 es " + x);
                  }
            }
        }else{
    
               System.out.println("Pierdes 100 y tu dado 1 es " + v + " tu dado 2 es " + x); 
           
           
            
        }
        
        
    }
}
